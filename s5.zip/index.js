<footer>
    <p>&copy; 2025 Rebouh Walaa. All rights reserved.</p>
  </footer>
  <div class="particles"></div>
<script>
  const particlesContainer = document.querySelector('.particles');
  for (let i = 0; i < 30; i++) {
    const star = document.createElement('div');
    star.className = 'star';
    star.style.top = `${Math.random() * 100}vh`;
    star.style.left = `${Math.random() * 100}vw`;
    star.style.animationDuration = `${4 + Math.random() * 6}s`;
    particlesContainer.appendChild(star);
  }
</script>
